import { GenrePipe } from './genre.pipe';

describe('GenrePipe', () => {
  it('create an instance', () => {
    const pipe = new GenrePipe();
    expect(pipe).toBeTruthy();
  });
});

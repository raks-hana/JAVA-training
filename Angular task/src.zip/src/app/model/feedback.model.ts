export interface Feedback {
  name: string;
  message: string;
  date: string;
}
  
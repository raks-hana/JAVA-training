export interface Enquiry {
    name: string;
    email: string;
    message: string;
    bookId: number; 
  }
  
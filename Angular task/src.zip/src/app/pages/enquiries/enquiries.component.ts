import { Component } from '@angular/core';

@Component({
  selector: 'app-enquiries',
  templateUrl: './enquiries.component.html',
  styleUrl: './enquiries.component.css'
})
export class EnquiriesComponent {
  constructor() { }

  ngOnInit(): void {
  }
}

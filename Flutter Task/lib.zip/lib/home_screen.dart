import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'localization.dart';
import 'pages/breathing_page.dart';
import 'pages/quotes_page.dart';
import 'pages/bubble_game_page.dart';
import 'pages/help_page.dart';
import 'login_page.dart';

class HomeScreen extends StatefulWidget {
  final Function(Locale) onLocaleChanged; // Accept the callback
  const HomeScreen({Key? key, required this.onLocaleChanged}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Locale _locale = Locale('en');

  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const LoginPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppLocalizations.of(context)?.translate('appTitle') ?? 'Stress Relief',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blueAccent,
        actions: [
          PopupMenuButton<Locale>(
            onSelected: (Locale locale) {
              setState(() {
                _locale = locale;
              });
              widget.onLocaleChanged(locale); // Call the callback to update locale
            },
            itemBuilder: (BuildContext context) {
              return [
                const PopupMenuItem(value: Locale('en'), child: Text('English')),
                const PopupMenuItem(value: Locale('fr'), child: Text('French')),
                const PopupMenuItem(value: Locale('es'), child: Text('Spanish')),
              ];
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildStyledButton(
                text: AppLocalizations.of(context)?.translate('breathingExercise') ?? 'Breathing Exercise',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const BreathingPage()),
                ),
              ),
              const SizedBox(height: 20),
              
              _buildStyledButton(
                text: AppLocalizations.of(context)?.translate('dailyQuotes') ?? 'Daily Quotes',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const QuotesPage()),
                ),
              ),
              const SizedBox(height: 20),
              
              _buildStyledButton(
                text: AppLocalizations.of(context)?.translate('bubbleGame') ?? 'Bubble Popping Game',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const BubbleGamePage()),
                ),
              ),
              const SizedBox(height: 20),
              
              _buildStyledButton(
                text: AppLocalizations.of(context)?.translate('getHelp') ?? 'Get Help',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const HelpPage()),
                ),
              ),
              const SizedBox(height: 20),
              
              _buildStyledButton(
                text: AppLocalizations.of(context)?.translate('logout') ?? 'Logout',
                onPressed: _logout,
                color: Colors.redAccent, 
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _buildStyledButton({
    required String text,
    required VoidCallback onPressed,
    Color color = Colors.blueAccent, 
  }) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 30),
      ),
      onPressed: onPressed,
      child: Text(
        text,
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
      ),
    );
  }
}

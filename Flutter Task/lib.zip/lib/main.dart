import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'login_page.dart';
import 'home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Locale _locale = Locale('en');

  void _onLocaleChanged(Locale locale) {
    setState(() {
      _locale = locale;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Stress Relief App',
      theme: ThemeData(primarySwatch: Colors.blue),
      locale: _locale, 
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        AppLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en', ''), // English
        Locale('fr', ''), // French
        Locale('es', ''), // Spanish
      ],
      home: AuthWrapper(onLocaleChanged: _onLocaleChanged), // Pass the locale change callback
    );
  }
}

class AuthWrapper extends StatelessWidget {
  final Function(Locale) onLocaleChanged;
  const AuthWrapper({super.key, required this.onLocaleChanged});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          if (snapshot.hasData) {
            return HomeScreen(onLocaleChanged: onLocaleChanged); // Pass the callback to HomeScreen
          }
          return const LoginPage();
        } else {
          return const Center(child: CircularProgressIndicator());
        }
      },
    );
  }
}

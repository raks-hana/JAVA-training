import 'package:flutter/material.dart';

class BreathingPage extends StatefulWidget {
  const BreathingPage({super.key});

  @override
  _BreathingPageState createState() => _BreathingPageState();
}

class _BreathingPageState extends State<BreathingPage> {
  int _seconds = 0;
  String _action = 'Inhale';

  @override
  void initState() {
    super.initState();
    _startBreathingExercise();
  }

  void _startBreathingExercise() {
    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        _seconds++;
        if (_seconds % 20 < 5) {
          _action = 'Inhale';
        } else if (_seconds % 20 < 10) {
          _action = 'Hold';
        } else if (_seconds % 20 < 15) {
          _action = 'Exhale';
        } else {
          _seconds = 0;
          _action = 'Inhale';
        }
      });
      _startBreathingExercise();
    });
  }

  void _resetExercise() {
    setState(() {
      _seconds = 0;
      _action = 'Inhale';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Breathing Exercise'),
        backgroundColor: Colors.teal,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal.shade100, Colors.teal.shade400],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Breathing action text
                Text(
                  'Action: $_action',
                  style: const TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 20),
                // Time text
                Text(
                  'Time: $_seconds s',
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 40),
                // Reset button
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal[700],
                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 40),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: _resetExercise,
                  child: const Text(
                    'Reset Exercise',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

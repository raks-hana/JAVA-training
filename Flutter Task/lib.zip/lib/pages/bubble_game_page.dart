import 'package:flutter/material.dart';
import 'dart:math';
import '../widgets/bubble.dart';

class BubbleGamePage extends StatefulWidget {
  const BubbleGamePage({Key? key}) : super(key: key);

  @override
  _BubbleGamePageState createState() => _BubbleGamePageState();
}

class _BubbleGamePageState extends State<BubbleGamePage> {
  final Random _random = Random();
  List<Map<String, dynamic>> bubbles = [];
  double screenWidth = 0;
  double screenHeight = 0;

  String bubbleImage = 'assets/bubble.png'; // Bubble image path

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        screenWidth = MediaQuery.of(context).size.width;
        screenHeight = MediaQuery.of(context).size.height;
        _generateBubbles();
      });
    });
  }

  void _generateBubbles() {
    bubbles.clear();
    for (int i = 0; i < 20; i++) {
      double size = _random.nextDouble() * 70 + 50; // Size between 50-120 px
      double left = _random.nextDouble() * (screenWidth - size);
      double top = _random.nextDouble() * (screenHeight - size - 100);

      bubbles.add({
        'id': i,
        'size': size,
        'left': left,
        'top': top,
      });
    };
  }

  void _popBubble(int id) {
    setState(() {
      bubbles.removeWhere((bubble) => bubble['id'] == id); // Remove only tapped bubble
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bubble Popping Game')),
      body: Stack(
        children: bubbles.map((bubble) {
          return Bubble(
            size: bubble['size'],
            left: bubble['left'],
            top: bubble['top'],
            bubbleImage: bubbleImage,
            onPop: () => _popBubble(bubble['id']), // Pop only this bubble
          );
        }).toList(),
      ),
    );
  }
}

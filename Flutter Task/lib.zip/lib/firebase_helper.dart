import 'package:cloud_firestore/cloud_firestore.dart';

Future<void> saveUserProgress(String userId, int score) async {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  await firestore.collection('users').doc(userId).set({
    'score': score,
    'lastActivity': 'home_screen',  // Track the last activity
  });
}


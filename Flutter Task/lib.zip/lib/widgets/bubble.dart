import 'package:flutter/material.dart';

class Bubble extends StatelessWidget {
  final double size;
  final double left;
  final double top;
  final String bubbleImage;
  final VoidCallback onPop;

  const Bubble({
    Key? key,
    required this.size,
    required this.left,
    required this.top,
    required this.bubbleImage,
    required this.onPop,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: left,
      top: top,
      child: GestureDetector(
        onTap: onPop, // Only removes the tapped bubble
        child: ClipOval(
          child: Image.asset(
            bubbleImage,
            width: size,
            height: size,
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}
